module.exports = {
  content: ["./src/**/*.{astro,js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        isabelline: "#F5F0F0",
      },
    },
  },
  plugins: [],
};
